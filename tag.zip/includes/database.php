<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$db = "db_deepgyan";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $db);
?>