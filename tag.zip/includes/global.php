<?php
	session_start();
	$site_path = "http://localhost/deepgyan/";
	$site_title = "DeepGyan";
?>