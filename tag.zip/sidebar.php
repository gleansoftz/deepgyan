<a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle"><i></i></a>
		<aside id="colorlib-aside" role="complementary" class="js-fullheight img" style="background-image: url(<?php echo $site_path;?>images/sidebar-bg.jpg);">
			<h1 id="colorlib-logo" class="mb-4"><a href="<?php echo $site_path;?>">DeepGyan</a></h1>
			<nav id="colorlib-main-menu" role="navigation">
				<ul>
					<li class="colorlib-active"><a href="<?php echo $site_path;?>">Home</a></li>
					<li><a href="<?php echo $site_path;?>blog/">Lifestyle</a></li>
					<li><a href="<?php echo $site_path;?>tag/">Travel</a></li>
					<li><a href="<?php echo $site_path;?>about.php">About</a></li>
					<li><a href="<?php echo $site_path;?>contact.php">Contact</a></li>
				</ul>
			</nav>

			<div class="colorlib-footer">
				<div class="mb-4">
					<h3>Subscribe for newsletter</h3>
					<form action="#" class="colorlib-subscribe-form">
            <div class="form-group d-flex">
            	<div class="icon"><span class="icon-paper-plane"></span></div>
              <input type="text" class="form-control" placeholder="Enter Email Address">
            </div>
          </form>
				</div>
				<p class="pfooter"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
	  Copyright &copy;<script>document.write(new Date().getFullYear());</script> <a href="<?php echo $site_path;?>">DeepGyan</a> All rights reserved | Developed by <a href="https://gleansoft.com" target="_blank">GleanSoft</a>
	  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
			</div>
		</aside> <!-- END COLORLIB-ASIDE -->